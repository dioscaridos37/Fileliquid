plugins {
    // AGP 9 имеет встроенный Kotlin, плагин kotlin-android не нужен.
    id("com.android.application") version "9.1.0" apply false
    id("org.jetbrains.kotlin.plugin.compose") version "2.3.0" apply false
}
