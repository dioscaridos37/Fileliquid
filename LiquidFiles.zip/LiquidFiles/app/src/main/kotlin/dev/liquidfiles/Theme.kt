package dev.liquidfiles

import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.SpringSpec
import androidx.compose.animation.core.spring
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.sp

val LocalAppSettings = compositionLocalOf { AppSettings() }
val LocalDark = compositionLocalOf { false }
val LocalMotion = compositionLocalOf { Motion(0.5f) }

/** Пружины всего приложения. bounce 0..1 управляет упругостью (демпфирование 0.85 → 0.35). */
class Motion(val bounce: Float) {
    val damping: Float get() = 0.85f - 0.5f * bounce.coerceIn(0f, 1f)
    fun <T> spec(stiffness: Float = Spring.StiffnessMediumLow): SpringSpec<T> =
        spring(dampingRatio = damping, stiffness = stiffness)
}

@Composable fun ink(): Color = if (LocalDark.current) Color(0xFFF2F2F7) else Color(0xFF1C1C1E)
@Composable fun inkSoft(): Color = ink().copy(alpha = 0.62f)

@Composable
fun LiquidTheme(s: AppSettings, content: @Composable () -> Unit) {
    val dark = when (s.themeMode) { 1 -> false; 2 -> true; else -> isSystemInDarkTheme() }
    val accent = Color(AccentPalette[s.accent.coerceIn(0, AccentPalette.lastIndex)])
    val fg = if (dark) Color(0xFFF2F2F7) else Color(0xFF1C1C1E)
    val bg = if (dark) Color(0xFF0E0E12) else Color(0xFFF1F1F4)
    val scheme = if (dark) darkColorScheme(
        primary = accent, onPrimary = Color.White, background = bg, surface = bg,
        onBackground = fg, onSurface = fg, onSurfaceVariant = fg.copy(.7f),
    ) else lightColorScheme(
        primary = accent, onPrimary = Color.White, background = bg, surface = bg,
        onBackground = fg, onSurface = fg, onSurfaceVariant = fg.copy(.7f),
    )
    MaterialTheme(colorScheme = scheme) {
        CompositionLocalProvider(
            LocalAppSettings provides s,
            LocalDark provides dark,
            LocalMotion provides Motion(s.bounce),
            androidx.compose.material3.LocalContentColor provides fg,
        ) { content() }
    }
}

@Composable
fun T(
    text: String,
    size: TextUnit = 15.sp,
    weight: FontWeight = FontWeight.Medium,
    color: Color = ink(),
    modifier: Modifier = Modifier,
    maxLines: Int = 1,
) = Text(text, modifier, color = color, fontSize = size, fontWeight = weight, maxLines = maxLines, overflow = TextOverflow.Ellipsis)

/** Фон-«обои»: цветные пятна, сквозь которые стекло красиво преломляется. */
@Composable
fun Wallpaper() {
    val s = LocalAppSettings.current
    val dark = LocalDark.current
    val accent = MaterialTheme.colorScheme.primary
    val base = if (dark) Color(0xFF0E0E12) else Color(0xFFF1F1F4)
    Canvas(Modifier.fillMaxSize()) {
        drawRect(base)
        val blobs: List<Triple<Offset, Float, Color>> = when (s.wallpaper) {
            0 -> listOf(
                Triple(Offset(size.width * .15f, size.height * .12f), size.width * .8f, accent.copy(alpha = if (dark) .30f else .20f)),
                Triple(Offset(size.width * .95f, size.height * .45f), size.width * .8f, Color(0xFF2E7BF6).copy(alpha = if (dark) .26f else .16f)),
                Triple(Offset(size.width * .2f, size.height * .92f), size.width * .9f, Color(0xFFFF2D87).copy(alpha = if (dark) .22f else .12f)),
            )
            1 -> listOf(
                Triple(Offset(size.width * .1f, size.height * .1f), size.width * .9f, Color(0xFF34C759).copy(alpha = if (dark) .32f else .22f)),
                Triple(Offset(size.width * .9f, size.height * .4f), size.width * .9f, Color(0xFFAF52DE).copy(alpha = if (dark) .32f else .20f)),
                Triple(Offset(size.width * .3f, size.height * .95f), size.width * .9f, Color(0xFF00BFFF).copy(alpha = if (dark) .28f else .18f)),
            )
            2 -> listOf(
                Triple(Offset(size.width * .9f, size.height * .08f), size.width * .9f, Color(0xFFFF9F0A).copy(alpha = if (dark) .34f else .26f)),
                Triple(Offset(size.width * .1f, size.height * .5f), size.width * .9f, Color(0xFFFF2D87).copy(alpha = if (dark) .30f else .20f)),
                Triple(Offset(size.width * .8f, size.height * .95f), size.width * .9f, Color(0xFF7B2FF7).copy(alpha = if (dark) .30f else .16f)),
            )
            else -> emptyList()
        }
        blobs.forEach { (c, r, col) ->
            drawCircle(Brush.radialGradient(listOf(col, Color.Transparent), center = c, radius = r), radius = r, center = c)
        }
    }
}
