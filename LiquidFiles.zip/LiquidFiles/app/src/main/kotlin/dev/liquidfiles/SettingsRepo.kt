package dev.liquidfiles

import android.content.Context
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.first

private val Context.dataStore by preferencesDataStore(name = "liquid_settings")

class SettingsRepo(private val ctx: Context) {
    private object K {
        val theme = intPreferencesKey("theme")
        val style = intPreferencesKey("style")
        val blur = floatPreferencesKey("blur")
        val alpha = floatPreferencesKey("alpha")
        val refr = floatPreferencesKey("refr")
        val aber = floatPreferencesKey("aber")
        val corner = floatPreferencesKey("corner")
        val accent = intPreferencesKey("accent")
        val wall = intPreferencesKey("wall")
        val bounce = floatPreferencesKey("bounce")
        val haptics = booleanPreferencesKey("haptics")
        val grid = booleanPreferencesKey("grid")
        val hidden = booleanPreferencesKey("hidden")
        val foldersFirst = booleanPreferencesKey("foldersFirst")
        val sortBy = intPreferencesKey("sortBy")
        val sortDesc = booleanPreferencesKey("sortDesc")
    }

    suspend fun load(): AppSettings {
        val p = ctx.dataStore.data.first()
        val d = AppSettings()
        return AppSettings(
            themeMode = p[K.theme] ?: d.themeMode,
            glassStyle = p[K.style] ?: d.glassStyle,
            blur = p[K.blur] ?: d.blur,
            glassAlpha = p[K.alpha] ?: d.glassAlpha,
            refraction = p[K.refr] ?: d.refraction,
            aberration = p[K.aber] ?: d.aberration,
            corner = p[K.corner] ?: d.corner,
            accent = p[K.accent] ?: d.accent,
            wallpaper = p[K.wall] ?: d.wallpaper,
            bounce = p[K.bounce] ?: d.bounce,
            haptics = p[K.haptics] ?: d.haptics,
            gridMode = p[K.grid] ?: d.gridMode,
            showHidden = p[K.hidden] ?: d.showHidden,
            foldersFirst = p[K.foldersFirst] ?: d.foldersFirst,
            sortBy = p[K.sortBy] ?: d.sortBy,
            sortDesc = p[K.sortDesc] ?: d.sortDesc,
        )
    }

    suspend fun save(s: AppSettings) {
        ctx.dataStore.edit { p ->
            p[K.theme] = s.themeMode
            p[K.style] = s.glassStyle
            p[K.blur] = s.blur
            p[K.alpha] = s.glassAlpha
            p[K.refr] = s.refraction
            p[K.aber] = s.aberration
            p[K.corner] = s.corner
            p[K.accent] = s.accent
            p[K.wall] = s.wallpaper
            p[K.bounce] = s.bounce
            p[K.haptics] = s.haptics
            p[K.grid] = s.gridMode
            p[K.hidden] = s.showHidden
            p[K.foldersFirst] = s.foldersFirst
            p[K.sortBy] = s.sortBy
            p[K.sortDesc] = s.sortDesc
        }
    }
}
