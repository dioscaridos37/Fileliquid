package dev.liquidfiles

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.core.content.FileProvider
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

fun formatSize(bytes: Long): String {
    if (bytes < 1024) return "$bytes Б"
    val u = arrayOf("КБ", "МБ", "ГБ", "ТБ")
    var v = bytes / 1024.0
    var i = 0
    while (v >= 1024 && i < u.lastIndex) { v /= 1024; i++ }
    return String.format(Locale.getDefault(), "%.1f %s", v, u[i])
}

fun formatDate(ms: Long): String =
    SimpleDateFormat("d MMM yyyy, HH:mm", Locale.getDefault()).format(Date(ms))

fun kindIcon(k: FileKind): ImageVector = when (k) {
    FileKind.FOLDER -> Icons.Rounded.Folder
    FileKind.IMAGE -> Icons.Rounded.Image
    FileKind.VIDEO -> Icons.Rounded.Movie
    FileKind.AUDIO -> Icons.Rounded.MusicNote
    FileKind.ARCHIVE -> Icons.Rounded.FolderZip
    FileKind.APK -> Icons.Rounded.Android
    FileKind.DOC -> Icons.Rounded.Description
    FileKind.OTHER -> Icons.Rounded.Description
}

fun kindColor(k: FileKind): Color = Color(
    when (k) {
        FileKind.FOLDER -> 0xFFFFB020
        FileKind.IMAGE -> 0xFF2E9BFF
        FileKind.VIDEO -> 0xFFAF52DE
        FileKind.AUDIO -> 0xFFFF4D8D
        FileKind.ARCHIVE -> 0xFFFF9500
        FileKind.APK -> 0xFF34C759
        FileKind.DOC -> 0xFF5E6AD2
        FileKind.OTHER -> 0xFF8E8E93
    }
)

fun categoryIcon(c: Category): ImageVector = when (c) {
    Category.IMAGES -> Icons.Rounded.Image
    Category.VIDEOS -> Icons.Rounded.Movie
    Category.AUDIO -> Icons.Rounded.MusicNote
    Category.DOCS -> Icons.Rounded.Description
    Category.ARCHIVES -> Icons.Rounded.FolderZip
    Category.APKS -> Icons.Rounded.Android
    Category.RECENT -> Icons.Rounded.History
}

fun categoryColor(c: Category): Color = when (c) {
    Category.IMAGES -> kindColor(FileKind.IMAGE)
    Category.VIDEOS -> kindColor(FileKind.VIDEO)
    Category.AUDIO -> kindColor(FileKind.AUDIO)
    Category.DOCS -> kindColor(FileKind.DOC)
    Category.ARCHIVES -> kindColor(FileKind.ARCHIVE)
    Category.APKS -> kindColor(FileKind.APK)
    Category.RECENT -> Color(0xFF00BFA5)
}

fun uriFor(ctx: Context, f: File): Uri =
    FileProvider.getUriForFile(ctx, "${ctx.packageName}.fileprovider", f)

fun openFile(ctx: Context, f: File, onError: (String) -> Unit) {
    val i = Intent(Intent.ACTION_VIEW)
        .setDataAndType(uriFor(ctx, f), FileOps.mimeOf(f))
        .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    try { ctx.startActivity(i) } catch (e: ActivityNotFoundException) { onError("Нет приложения для этого файла") }
}

fun shareFiles(ctx: Context, files: List<File>, onError: (String) -> Unit) {
    val only = files.filter { it.isFile }
    if (only.isEmpty()) { onError("Папки нельзя отправить: сначала заархивируйте"); return }
    val uris = ArrayList(only.map { uriFor(ctx, it) })
    val i: Intent
    if (uris.size == 1) {
        i = Intent(Intent.ACTION_SEND)
        i.putExtra(Intent.EXTRA_STREAM, uris[0])
        i.setType(FileOps.mimeOf(only[0]))
    } else {
        i = Intent(Intent.ACTION_SEND_MULTIPLE)
        i.putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris)
        i.setType("*/*")
    }
    i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    ctx.startActivity(Intent.createChooser(i, "Поделиться"))
}
