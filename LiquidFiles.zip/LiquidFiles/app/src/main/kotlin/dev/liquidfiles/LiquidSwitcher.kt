package dev.liquidfiles

import android.graphics.RenderEffect
import android.graphics.RuntimeShader
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.drag
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.RoundRect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.graphics.vector.ImageVector
import kotlinx.coroutines.launch
import kotlin.math.abs
import kotlin.math.min

data class TabSpec(val label: String, val icon: ImageVector? = null)

/**
 * AGSL-шейдер линзы: внутри капсулы содержимое слегка увеличено, у краёв «загибается»
 * внутрь (преломление) и раскладывается по каналам R/G/B (хроматическая аберрация).
 */
private const val LENS_AGSL = """
uniform shader content;
uniform float4 lens;
uniform float amount;
uniform float refr;
uniform float aber;

float sdBox(float2 p, float2 h, float r) {
    float2 q = abs(p) - h + float2(r);
    return length(max(q, float2(0.0))) + min(max(q.x, q.y), 0.0) - r;
}

half4 main(float2 frag) {
    float2 c = lens.xy;
    float2 h = lens.zw;
    float r = min(h.x, h.y);
    float2 p = frag - c;
    float d = sdBox(p, h, r);
    if (d > 0.0 || amount < 0.001) {
        return content.eval(frag);
    }
    float e = 1.0;
    float2 g = float2(
        sdBox(p + float2(e, 0.0), h, r) - sdBox(p - float2(e, 0.0), h, r),
        sdBox(p + float2(0.0, e), h, r) - sdBox(p - float2(0.0, e), h, r));
    float gl = length(g);
    g = gl > 0.0001 ? g / gl : float2(0.0);
    float depth = clamp(-d / (r * 0.85), 0.0, 1.0);
    float bend = pow(1.0 - depth, 3.0);
    float k = amount * refr;
    float2 base = c + p * (1.0 - 0.14 * k);
    float2 shift = g * bend * r * 0.7 * k;
    float2 s = base - shift;
    float2 ca = g * bend * r * 0.22 * aber * amount;
    half4 cr = content.eval(s + ca);
    half4 cg = content.eval(s);
    half4 cb = content.eval(s - ca);
    half a = max(cr.a, max(cg.a, cb.a));
    return half4(cr.r, cg.g, cb.b, a);
}
"""

/**
 * Переключатель с «жидкой линзой», как на референсах: в покое — плоская капсула с акцентным
 * цветом внутри; при касании линза раздувается, получает белый ободок и преломление,
 * при движении растягивается по скорости и упруго приземляется на вкладку.
 */
@Composable
fun LiquidSwitcher(
    items: List<TabSpec>,
    selected: Int,
    onSelect: (Int) -> Unit,
    modifier: Modifier = Modifier,
    height: Dp = 76.dp,
    textSize: TextUnit = 12.5.sp,
) {
    val s = LocalAppSettings.current
    val motion = LocalMotion.current
    val dark = LocalDark.current
    val accent = MaterialTheme.colorScheme.primary
    val density = LocalDensity.current
    val haptic = LocalHapticFeedback.current
    val scope = rememberCoroutineScope()
    val shader = remember { RuntimeShader(LENS_AGSL) }

    var width by remember { mutableFloatStateOf(0f) }
    val x = remember { Animatable(0f) }
    val press = remember { Animatable(0f) }
    var dragging by remember { mutableStateOf(false) }

    val padPx = with(density) { 6.dp.toPx() }
    val last = items.lastIndex
    val itemW = ((width - 2 * padPx) / items.size).coerceAtLeast(1f)
    fun centerOf(i: Int) = padPx + itemW * (i + 0.5f)

    LaunchedEffect(width, selected, items.size) {
        if (width > 0f && !dragging) {
            if (x.value == 0f) x.snapTo(centerOf(selected))
            else x.animateTo(centerOf(selected), motion.spec<Float>())
        }
    }

    /** Геометрия линзы: cx, cy, полуширина, полувысота. Растяжение зависит от скорости пружины. */
    fun lens(h: Float): FloatArray {
        val p = press.value
        val stretch = (abs(x.velocity) / 5000f).coerceAtMost(0.5f)
        val baseHW = itemW / 2f - with(density) { 2.dp.toPx() }
        val baseHH = h / 2f - with(density) { 7.dp.toPx() }
        val hw = baseHW * (1f + 0.08f * p + stretch)
        val hh = baseHH * (1f + 0.30f * p) * (1f - 0.30f * stretch)
        return floatArrayOf(x.value, h / 2f, hw, hh)
    }

    fun lensPath(h: Float): Path {
        val g = lens(h)
        return Path().apply {
            addRoundRect(RoundRect(g[0] - g[2], g[1] - g[3], g[0] + g[2], g[1] + g[3], CornerRadius(min(g[2], g[3]))))
        }
    }

    GlassSurface(
        modifier
            .fillMaxWidth()
            .height(height)
            .onSizeChanged { width = it.width.toFloat() }
            .pointerInput(items.size, width) {
                if (width <= 0f) return@pointerInput
                awaitEachGesture {
                    val down = awaitFirstDown()
                    dragging = true
                    val minX = centerOf(0)
                    val maxX = centerOf(last)
                    var lastIdx = ((down.position.x - padPx) / itemW).toInt().coerceIn(0, last)
                    val follow = spring<Float>(dampingRatio = 0.8f, stiffness = Spring.StiffnessMedium)
                    scope.launch { press.animateTo(1f, motion.spec<Float>(Spring.StiffnessMedium)) }
                    scope.launch { x.animateTo(down.position.x.coerceIn(minX, maxX), follow) }
                    drag(down.id) { ch ->
                        ch.consume()
                        val px = ch.position.x.coerceIn(minX, maxX)
                        scope.launch { x.animateTo(px, follow) }
                        val idx = ((px - padPx) / itemW).toInt().coerceIn(0, last)
                        if (idx != lastIdx) {
                            lastIdx = idx
                            if (s.haptics) haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                        }
                    }
                    dragging = false
                    onSelect(lastIdx)
                    scope.launch { x.animateTo(centerOf(lastIdx), motion.spec<Float>()) }
                    scope.launch { press.animateTo(0f, motion.spec<Float>(Spring.StiffnessLow)) }
                }
            },
        shape = RoundedCornerShape(50),
    ) {
        Box(Modifier.fillMaxSize()) {
            // 1. Тело линзы (заливка), под иконками
            Box(Modifier.fillMaxSize().drawBehind {
                if (width <= 0f) return@drawBehind
                val g = lens(size.height)
                val p = press.value
                val tl = Offset(g[0] - g[2], g[1] - g[3])
                val sz = Size(g[2] * 2, g[3] * 2)
                val cr = CornerRadius(min(g[2], g[3]))
                drawRoundRect(
                    color = (if (dark) Color.White else Color.Black).copy(alpha = 0.09f * (1f - p)),
                    topLeft = tl, size = sz, cornerRadius = cr,
                )
                if (p > 0.01f) {
                    val hi = if (dark) 0.26f else 0.55f
                    val lo = if (dark) 0.08f else 0.16f
                    drawRoundRect(
                        brush = Brush.verticalGradient(
                            listOf(Color.White.copy(alpha = hi * p), Color.White.copy(alpha = lo * p)),
                            startY = tl.y, endY = tl.y + sz.height,
                        ),
                        topLeft = tl, size = sz, cornerRadius = cr,
                    )
                }
            })

            // 2. Иконки и подписи; слой с шейдером преломления
            Box(
                Modifier.fillMaxSize().graphicsLayer {
                    val p = press.value
                    if (p > 0.01f && s.refraction > 0.01f && width > 0f) {
                        val g = lens(size.height)
                        shader.setFloatUniform("lens", g[0], g[1], g[2], g[3])
                        shader.setFloatUniform("amount", p)
                        shader.setFloatUniform("refr", s.refraction)
                        shader.setFloatUniform("aber", s.aberration)
                        renderEffect = RenderEffect.createRuntimeShaderEffect(shader, "content").asComposeRenderEffect()
                    } else {
                        renderEffect = null
                    }
                }
            ) {
                // неактивные цвета везде, кроме области линзы
                Box(Modifier.fillMaxSize().drawWithContent {
                    clipPath(lensPath(size.height), ClipOp.Difference) { this@drawWithContent.drawContent() }
                }) { TabsRow(items, active = false, accent = accent, textSize = textSize) }
                // активные цвета только внутри линзы
                Box(Modifier.fillMaxSize().drawWithContent {
                    clipPath(lensPath(size.height)) { this@drawWithContent.drawContent() }
                }) { TabsRow(items, active = true, accent = accent, textSize = textSize) }
            }

            // 3. Ободок линзы и радужные блики сверху
            Box(Modifier.fillMaxSize().drawBehind {
                val p = press.value
                if (width <= 0f || p < 0.01f) return@drawBehind
                val g = lens(size.height)
                val tl = Offset(g[0] - g[2], g[1] - g[3])
                val sz = Size(g[2] * 2, g[3] * 2)
                val cr = CornerRadius(min(g[2], g[3]))
                drawRoundRect(
                    color = Color.White.copy(alpha = 0.95f * p),
                    topLeft = tl, size = sz, cornerRadius = cr, style = Stroke(2.4.dp.toPx()),
                )
                val inset = 4.dp.toPx()
                drawRoundRect(
                    brush = Brush.verticalGradient(
                        0f to Color(0xFFFF4DD2).copy(alpha = 0.55f * p),
                        0.2f to Color.Transparent,
                        0.8f to Color.Transparent,
                        1f to Color(0xFFFFE14D).copy(alpha = 0.55f * p),
                        startY = tl.y, endY = tl.y + sz.height,
                    ),
                    topLeft = Offset(tl.x + inset, tl.y + inset),
                    size = Size(sz.width - 2 * inset, sz.height - 2 * inset),
                    cornerRadius = CornerRadius(min(g[2], g[3]) - inset),
                    style = Stroke(2.dp.toPx()),
                )
            })
        }
    }
}

@Composable
private fun TabsRow(items: List<TabSpec>, active: Boolean, accent: Color, textSize: TextUnit) {
    val dark = LocalDark.current
    Row(Modifier.fillMaxSize().padding(horizontal = 6.dp)) {
        items.forEach { spec ->
            Box(Modifier.weight(1f).fillMaxHeight(), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    if (spec.icon != null) {
                        val circle = if (active) accent else if (dark) Color(0xFF8E8E93) else Color(0xFF4F4F54)
                        Box(Modifier.size(32.dp).clip(CircleShape).background(circle), contentAlignment = Alignment.Center) {
                            Icon(spec.icon, null, tint = Color.White, modifier = Modifier.size(19.dp))
                        }
                        Spacer(Modifier.height(3.dp))
                    }
                    T(
                        spec.label, size = textSize,
                        weight = if (active) FontWeight.SemiBold else FontWeight.Medium,
                        color = if (active) accent else inkSoft(),
                    )
                }
            }
        }
    }
}
