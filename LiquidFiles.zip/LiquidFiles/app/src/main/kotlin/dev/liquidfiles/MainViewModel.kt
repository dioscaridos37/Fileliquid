package dev.liquidfiles

import android.app.Application
import android.os.Environment
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

class MainViewModel(app: Application) : AndroidViewModel(app) {
    private val repo = SettingsRepo(app)
    val root: File = Environment.getExternalStorageDirectory()

    var ready by mutableStateOf(false); private set
    var settings by mutableStateOf(AppSettings()); private set

    var currentDir by mutableStateOf(root); private set
    var category by mutableStateOf<Category?>(null); private set
    var entries by mutableStateOf<List<FileEntry>>(emptyList()); private set
    var recent by mutableStateOf<List<FileEntry>>(emptyList()); private set
    var loading by mutableStateOf(false); private set
    var storage by mutableStateOf(StorageInfo()); private set

    var query by mutableStateOf(""); private set
    var searching by mutableStateOf(false); private set

    var selection by mutableStateOf<Set<File>>(emptySet()); private set
    var clipboard by mutableStateOf<List<File>>(emptyList()); private set
    var clipCut by mutableStateOf(false); private set
    var message by mutableStateOf<String?>(null)

    private var job: Job? = null
    private var saveJob: Job? = null

    init {
        viewModelScope.launch {
            settings = repo.load()
            ready = true
            refresh()
            loadStorage()
        }
    }

    // ---------- настройки ----------
    fun update(t: (AppSettings) -> AppSettings) {
        val old = settings
        val n = t(old)
        settings = n
        saveJob?.cancel()
        saveJob = viewModelScope.launch { delay(350); repo.save(n) }
        if (old.showHidden != n.showHidden || old.sortBy != n.sortBy ||
            old.sortDesc != n.sortDesc || old.foldersFirst != n.foldersFirst
        ) refresh()
    }

    // ---------- навигация ----------
    fun openDir(f: File) {
        category = null; query = ""; searching = false; selection = emptySet()
        currentDir = f
        refresh()
    }

    fun openCategory(c: Category) {
        category = c; query = ""; searching = false; selection = emptySet()
        refresh()
    }

    /** true, если «назад» обработано внутри файлового менеджера. */
    fun goUp(): Boolean {
        if (selection.isNotEmpty()) { selection = emptySet(); return true }
        if (searching) { closeSearch(); return true }
        if (category != null) { category = null; refresh(); return true }
        val parent = currentDir.parentFile
        if (currentDir.path != root.path && parent != null) { openDir(parent); return true }
        return false
    }

    val atRoot: Boolean get() = category == null && currentDir.path == root.path

    fun startSearch() { searching = true }
    fun closeSearch() { searching = false; query = ""; refresh() }
    fun onQuery(q: String) { query = q; refresh(debounce = true) }

    fun refresh(debounce: Boolean = false) {
        job?.cancel()
        job = viewModelScope.launch {
            loading = true
            if (debounce) delay(250)
            val s = settings; val cat = category; val q = query; val dir = currentDir
            val ctx = getApplication<Application>()
            entries = withContext(Dispatchers.IO) {
                when {
                    searching && q.isNotBlank() -> FileOps.search(dir, q, s, { isActive })
                    cat != null -> FileOps.queryCategory(ctx, cat, s)
                    else -> FileOps.list(dir, s)
                }
            }
            loading = false
        }
    }

    fun loadRecent() {
        viewModelScope.launch {
            val ctx = getApplication<Application>()
            val s = settings
            recent = withContext(Dispatchers.IO) { FileOps.queryCategory(ctx, Category.RECENT, s, 80) }
        }
    }

    fun loadStorage() {
        viewModelScope.launch { storage = withContext(Dispatchers.IO) { FileOps.storage() } }
    }

    // ---------- выделение / буфер ----------
    fun toggle(f: File) { selection = if (f in selection) selection - f else selection + f }
    fun selectAll() { selection = entries.map { it.file }.toSet() }
    fun clearSelection() { selection = emptySet() }

    fun copySelected() { clipboard = selection.toList(); clipCut = false; selection = emptySet() }
    fun cutSelected() { clipboard = selection.toList(); clipCut = true; selection = emptySet() }
    fun clearClipboard() { clipboard = emptyList() }

    // ---------- операции ----------
    private fun io(done: String? = null, block: () -> Unit) {
        viewModelScope.launch {
            loading = true
            try {
                withContext(Dispatchers.IO) { block() }
                if (done != null) message = done
            } catch (e: Exception) {
                message = e.message ?: "Ошибка"
            }
            refresh()
            loadStorage()
        }
    }

    fun paste() {
        if (category != null) return
        val dest = currentDir; val items = clipboard; val cut = clipCut
        io("Готово") {
            items.forEach { src ->
                val dst = FileOps.unique(dest, src.name)
                if (cut) FileOps.move(src, dst) else FileOps.copy(src, dst)
            }
        }
        if (cut) clipboard = emptyList()
    }

    fun delete(files: List<File>) { selection = emptySet(); io("Удалено") { files.forEach { it.deleteRecursively() } } }

    fun rename(f: File, name: String) {
        selection = emptySet()
        io {
            val dst = File(f.parentFile, name.trim())
            if (dst.exists()) throw IllegalStateException("Такое имя уже есть")
            if (!f.renameTo(dst)) throw IllegalStateException("Не удалось переименовать")
        }
    }

    fun newFolder(name: String) = io {
        val d = File(currentDir, name.trim())
        if (d.exists()) throw IllegalStateException("Такое имя уже есть")
        if (!d.mkdirs()) throw IllegalStateException("Не удалось создать папку")
    }

    fun newFile(name: String) = io {
        val f = File(currentDir, name.trim())
        if (f.exists()) throw IllegalStateException("Такое имя уже есть")
        if (!f.createNewFile()) throw IllegalStateException("Не удалось создать файл")
    }

    fun zipSelected() {
        val files = selection.toList(); selection = emptySet()
        if (files.isEmpty()) return
        val dir = files[0].parentFile ?: currentDir
        val base = if (files.size == 1) files[0].nameWithoutExtension else "Архив"
        io("Архив создан") { FileOps.zip(files, FileOps.unique(dir, "$base.zip")) }
    }

    fun unzip(f: File) {
        selection = emptySet()
        val dir = f.parentFile ?: currentDir
        io("Распаковано") { FileOps.unzip(f, FileOps.unique(dir, f.nameWithoutExtension)) }
    }
}
