package dev.liquidfiles

import java.io.File

enum class FileKind { FOLDER, IMAGE, VIDEO, AUDIO, ARCHIVE, APK, DOC, OTHER }

data class FileEntry(
    val file: File,
    val isDir: Boolean,
    val size: Long,
    val modified: Long,
    val kind: FileKind,
    val children: Int = -1,
) {
    val name: String get() = file.name
}

enum class Category(val title: String) {
    IMAGES("Изображения"),
    VIDEOS("Видео"),
    AUDIO("Аудио"),
    DOCS("Документы"),
    ARCHIVES("Архивы"),
    APKS("Приложения"),
    RECENT("Недавние"),
}

data class StorageInfo(val total: Long = 0, val free: Long = 0) {
    val used: Long get() = total - free
    val fraction: Float get() = if (total > 0) used.toFloat() / total else 0f
}

/** Все настройки внешнего вида и поведения. Меняются в разделе «Настройки». */
data class AppSettings(
    val themeMode: Int = 0,          // 0 система, 1 светлая, 2 тёмная
    val glassStyle: Int = 0,         // 0 Liquid, 1 Frosted, 2 Clear, 3 Solid
    val blur: Float = 26f,           // радиус размытия фона за стеклом, dp
    val glassAlpha: Float = 0.34f,   // плотность заливки стекла
    val refraction: Float = 0.8f,    // сила преломления линзы
    val aberration: Float = 0.6f,    // хроматическая аберрация по краям линзы
    val corner: Float = 26f,         // скругление панелей, dp
    val accent: Int = 0,             // индекс в AccentPalette
    val wallpaper: Int = 0,          // индекс в Wallpapers
    val bounce: Float = 0.65f,       // 0 = плавно, 1 = очень прыгуче
    val haptics: Boolean = true,
    val gridMode: Boolean = false,
    val showHidden: Boolean = false,
    val foldersFirst: Boolean = true,
    val sortBy: Int = 0,             // 0 имя, 1 размер, 2 дата, 3 тип
    val sortDesc: Boolean = false,
)

fun AppSettings.withPreset(i: Int): AppSettings = when (i) {
    0 -> copy(glassStyle = 0, blur = 26f, glassAlpha = 0.34f, refraction = 0.8f, aberration = 0.6f)
    1 -> copy(glassStyle = 1, blur = 48f, glassAlpha = 0.58f, refraction = 0.3f, aberration = 0.1f)
    2 -> copy(glassStyle = 2, blur = 8f, glassAlpha = 0.16f, refraction = 1.0f, aberration = 0.9f)
    else -> copy(glassStyle = 3, blur = 0f, glassAlpha = 0.94f, refraction = 0.0f, aberration = 0.0f)
}

val AccentPalette = listOf(
    0xFFEF5350, 0xFF2E7BF6, 0xFF34C759, 0xFFFF9F0A,
    0xFFAF52DE, 0xFFFF2D87, 0xFF00BFA5, 0xFF607D8B,
)

val Wallpapers = listOf("Мягкий", "Аврора", "Закат", "Чистый")
val GlassPresets = listOf("Liquid", "Frosted", "Clear", "Solid")
