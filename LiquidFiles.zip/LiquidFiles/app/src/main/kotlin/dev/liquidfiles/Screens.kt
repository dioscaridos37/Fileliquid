package dev.liquidfiles

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import java.io.File

// ======================= ГЛАВНАЯ =======================

@Composable
fun HomeScreen(vm: MainViewModel, onCategory: (Category) -> Unit, onFolder: (File) -> Unit) {
    val top = WindowInsets.statusBars.asPaddingValues().calculateTopPadding()
    val st = vm.storage
    val frac by animateFloatAsState(
        targetValue = st.fraction,
        animationSpec = LocalMotion.current.spec(),
        label = "storage",
    )
    val cats = listOf(Category.IMAGES, Category.VIDEOS, Category.AUDIO, Category.DOCS, Category.ARCHIVES, Category.APKS)
    val quick = listOf(
        "Загрузки" to "Download", "Камера" to "DCIM", "Документы" to "Documents",
        "Картинки" to "Pictures", "Музыка" to "Music", "Фильмы" to "Movies",
    )

    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = top + 16.dp, bottom = 150.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        item {
            T("Файлы", size = 34.sp, weight = FontWeight.Bold)
            T("Внутренняя память", size = 14.sp, color = inkSoft())
        }
        item {
            GlassSurface(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(18.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Rounded.Storage, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(22.dp))
                        Spacer(Modifier.width(8.dp))
                        T("Хранилище", size = 16.sp, weight = FontWeight.SemiBold)
                    }
                    Spacer(Modifier.height(14.dp))
                    Box(
                        Modifier.fillMaxWidth().height(12.dp).clip(CircleShape)
                            .background(ink().copy(alpha = 0.10f))
                    ) {
                        Box(
                            Modifier.fillMaxWidth(frac.coerceIn(0.02f, 1f)).fillMaxHeight().clip(CircleShape)
                                .background(MaterialTheme.colorScheme.primary)
                        )
                    }
                    Spacer(Modifier.height(10.dp))
                    T("${formatSize(st.used)} из ${formatSize(st.total)}  ·  свободно ${formatSize(st.free)}", size = 13.sp, color = inkSoft())
                }
            }
        }
        item { T("Категории", size = 20.sp, weight = FontWeight.SemiBold) }
        items(cats.chunked(3)) { row ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                row.forEach { c ->
                    GlassSurface(
                        Modifier.weight(1f).bouncy { onCategory(c) },
                        shape = RoundedCornerShape(22.dp), blur = false,
                    ) {
                        Column(Modifier.fillMaxWidth().padding(vertical = 16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                            Box(
                                Modifier.size(44.dp).clip(CircleShape).background(categoryColor(c)),
                                contentAlignment = Alignment.Center,
                            ) { Icon(categoryIcon(c), null, tint = Color.White, modifier = Modifier.size(24.dp)) }
                            Spacer(Modifier.height(8.dp))
                            T(c.title, size = 13.sp)
                        }
                    }
                }
            }
        }
        item { T("Быстрый доступ", size = 20.sp, weight = FontWeight.SemiBold) }
        items(quick) { (title, dir) ->
            GlassSurface(
                Modifier.fillMaxWidth().bouncy { onFolder(File(vm.root, dir)) },
                shape = RoundedCornerShape(20.dp), blur = false,
            ) {
                Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Rounded.Folder, null, tint = kindColor(FileKind.FOLDER), modifier = Modifier.size(28.dp))
                    Spacer(Modifier.width(12.dp))
                    T(title, size = 16.sp)
                }
            }
        }
    }
}

// ======================= СПИСОК / СЕТКА ФАЙЛОВ =======================

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun FileCollection(
    entries: List<FileEntry>,
    grid: Boolean,
    selection: Set<File>,
    topPad: Dp,
    bottomPad: Dp,
    loading: Boolean,
    onClick: (FileEntry) -> Unit,
    onLong: (FileEntry) -> Unit,
) {
    val motion = LocalMotion.current
    if (entries.isEmpty()) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            T(if (loading) "Загрузка…" else "Здесь пусто", size = 16.sp, color = inkSoft())
        }
        return
    }
    if (grid) {
        LazyVerticalGrid(
            columns = GridCells.Adaptive(112.dp),
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = topPad, bottom = bottomPad),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            items(entries, key = { it.file.path }) { e ->
                val sel = e.file in selection
                GlassSurface(
                    Modifier.animateItem(placementSpec = motion.spec()).bouncy(onLongClick = { onLong(e) }) { onClick(e) },
                    shape = RoundedCornerShape(20.dp), blur = false, shadow = false,
                    tint = if (sel) MaterialTheme.colorScheme.primary else null,
                ) {
                    Column(Modifier.padding(10.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Thumb(e, 84.dp)
                        Spacer(Modifier.height(6.dp))
                        T(e.name, size = 12.5.sp)
                        T(subtitle(e), size = 11.sp, color = inkSoft())
                    }
                    CheckBubble(sel, Modifier.align(Alignment.TopEnd).padding(8.dp))
                }
            }
        }
    } else {
        LazyColumn(
            Modifier.fillMaxSize(),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = topPad, bottom = bottomPad),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            items(entries, key = { it.file.path }) { e ->
                val sel = e.file in selection
                GlassSurface(
                    Modifier.fillMaxWidth().animateItem(placementSpec = motion.spec()).bouncy(onLongClick = { onLong(e) }) { onClick(e) },
                    shape = RoundedCornerShape(20.dp), blur = false, shadow = false,
                    tint = if (sel) MaterialTheme.colorScheme.primary else null,
                ) {
                    Row(Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                        Thumb(e, 48.dp)
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            T(e.name, size = 15.5.sp)
                            T(subtitle(e), size = 12.5.sp, color = inkSoft())
                        }
                        CheckBubble(sel, Modifier)
                    }
                }
            }
        }
    }
}

private fun subtitle(e: FileEntry): String =
    if (e.isDir) "${e.children} эл.  ·  ${formatDate(e.modified)}"
    else "${formatSize(e.size)}  ·  ${formatDate(e.modified)}"

@Composable
private fun Thumb(e: FileEntry, size: Dp) {
    val color = kindColor(e.kind)
    Box(
        Modifier.size(size).clip(RoundedCornerShape(size * 0.28f)).background(color.copy(alpha = 0.16f)),
        contentAlignment = Alignment.Center,
    ) {
        if (e.kind == FileKind.IMAGE || e.kind == FileKind.VIDEO) {
            AsyncImage(
                model = e.file, contentDescription = null,
                contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize(),
            )
        } else {
            Icon(kindIcon(e.kind), null, tint = color, modifier = Modifier.size(size * 0.5f))
        }
    }
}

/** Галочка выбора, которая выпрыгивает пружиной. */
@Composable
private fun CheckBubble(selected: Boolean, modifier: Modifier) {
    val sc by animateFloatAsState(if (selected) 1f else 0f, LocalMotion.current.spec(), label = "check")
    Box(
        modifier.size(24.dp).graphicsLayer { scaleX = sc; scaleY = sc; alpha = sc.coerceIn(0f, 1f) }
            .clip(CircleShape).background(MaterialTheme.colorScheme.primary),
        contentAlignment = Alignment.Center,
    ) { Icon(Icons.Rounded.Check, null, tint = Color.White, modifier = Modifier.size(16.dp)) }
}
