package dev.liquidfiles

import android.content.Context
import android.os.Bundle
import android.os.Environment
import android.os.StatFs
import android.provider.MediaStore
import android.provider.MediaStore.Files.FileColumns as F
import android.webkit.MimeTypeMap
import java.io.File
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

object FileOps {
    private val imageExt = setOf("jpg", "jpeg", "png", "gif", "webp", "bmp", "heic", "heif", "avif")
    private val videoExt = setOf("mp4", "mkv", "webm", "avi", "mov", "3gp", "m4v", "ts")
    private val audioExt = setOf("mp3", "m4a", "aac", "wav", "flac", "ogg", "opus", "amr")
    private val archiveExt = setOf("zip", "rar", "7z", "tar", "gz", "bz2", "xz")
    private val docExt = setOf("pdf", "doc", "docx", "xls", "xlsx", "ppt", "pptx", "txt", "md", "epub", "odt", "rtf", "csv")

    fun kindOf(name: String, isDir: Boolean): FileKind {
        if (isDir) return FileKind.FOLDER
        val e = name.substringAfterLast('.', "").lowercase()
        return when {
            e in imageExt -> FileKind.IMAGE
            e in videoExt -> FileKind.VIDEO
            e in audioExt -> FileKind.AUDIO
            e in archiveExt -> FileKind.ARCHIVE
            e == "apk" -> FileKind.APK
            e in docExt -> FileKind.DOC
            else -> FileKind.OTHER
        }
    }

    fun mimeOf(f: File): String =
        MimeTypeMap.getSingleton().getMimeTypeFromExtension(f.extension.lowercase()) ?: "*/*"

    fun toEntry(f: File): FileEntry {
        val dir = f.isDirectory
        return FileEntry(
            file = f,
            isDir = dir,
            size = if (dir) 0L else f.length(),
            modified = f.lastModified(),
            kind = kindOf(f.name, dir),
            children = if (dir) (f.list()?.size ?: 0) else -1,
        )
    }

    fun sort(list: List<FileEntry>, s: AppSettings): List<FileEntry> {
        var cmp: Comparator<FileEntry> = when (s.sortBy) {
            1 -> compareBy<FileEntry> { it.size }
            2 -> compareBy<FileEntry> { it.modified }
            3 -> compareBy<FileEntry>({ it.file.extension.lowercase() }, { it.name.lowercase() })
            else -> compareBy<FileEntry> { it.name.lowercase() }
        }
        if (s.sortDesc) cmp = cmp.reversed()
        return if (s.foldersFirst) {
            list.sortedWith(compareByDescending<FileEntry> { it.isDir }.then(cmp))
        } else list.sortedWith(cmp)
    }

    fun list(dir: File, s: AppSettings): List<FileEntry> {
        val arr = dir.listFiles() ?: return emptyList()
        val items = arr.asSequence()
            .filter { s.showHidden || !it.name.startsWith(".") }
            .map { toEntry(it) }
            .toList()
        return sort(items, s)
    }

    fun search(root: File, q: String, s: AppSettings, active: () -> Boolean, limit: Int = 400): List<FileEntry> =
        root.walkTopDown()
            .onEnter { s.showHidden || !it.name.startsWith(".") }
            .takeWhile { active() }
            .filter { it != root && it.name.contains(q, ignoreCase = true) }
            .take(limit)
            .map { toEntry(it) }
            .toList()

    @Suppress("DEPRECATION")
    fun queryCategory(ctx: Context, cat: Category, s: AppSettings, limit: Int = 600): List<FileEntry> {
        val uri = MediaStore.Files.getContentUri("external")
        fun byExt(vararg e: String): Pair<String, Array<String>> =
            e.joinToString(" OR ") { "${F.DATA} LIKE ?" } to e.map { "%.$it" }.toTypedArray()

        val (sel, args) = when (cat) {
            Category.IMAGES -> "${F.MEDIA_TYPE}=?" to arrayOf(F.MEDIA_TYPE_IMAGE.toString())
            Category.VIDEOS -> "${F.MEDIA_TYPE}=?" to arrayOf(F.MEDIA_TYPE_VIDEO.toString())
            Category.AUDIO -> "${F.MEDIA_TYPE}=?" to arrayOf(F.MEDIA_TYPE_AUDIO.toString())
            Category.DOCS -> byExt("pdf", "doc", "docx", "xls", "xlsx", "ppt", "pptx", "txt", "epub", "odt", "csv")
            Category.ARCHIVES -> byExt("zip", "rar", "7z", "tar", "gz")
            Category.APKS -> byExt("apk")
            Category.RECENT -> "${F.SIZE}>?" to arrayOf("0")
        }
        val q = Bundle().apply {
            putString(android.content.ContentResolver.QUERY_ARG_SQL_SELECTION, sel)
            putStringArray(android.content.ContentResolver.QUERY_ARG_SQL_SELECTION_ARGS, args)
            putString(android.content.ContentResolver.QUERY_ARG_SQL_SORT_ORDER, "${F.DATE_MODIFIED} DESC")
            putInt(android.content.ContentResolver.QUERY_ARG_LIMIT, limit)
        }
        val out = ArrayList<FileEntry>()
        ctx.contentResolver.query(uri, arrayOf(F.DATA), q, null)?.use { c ->
            val i = c.getColumnIndexOrThrow(F.DATA)
            while (c.moveToNext()) {
                val path = c.getString(i) ?: continue
                val f = File(path)
                if (!f.isFile) continue
                if (!s.showHidden && path.contains("/.")) continue
                out += toEntry(f)
            }
        }
        return if (cat == Category.RECENT) out else sort(out, s)
    }

    fun storage(): StorageInfo {
        val st = StatFs(Environment.getExternalStorageDirectory().path)
        return StorageInfo(total = st.blockCountLong * st.blockSizeLong, free = st.availableBytes)
    }

    fun unique(dir: File, name: String): File {
        var f = File(dir, name)
        if (!f.exists()) return f
        val base = name.substringBeforeLast('.', name)
        val ext = if (name.contains('.')) "." + name.substringAfterLast('.') else ""
        var n = 1
        while (f.exists()) { f = File(dir, "$base ($n)$ext"); n++ }
        return f
    }

    fun copy(src: File, dst: File) {
        if (src.isDirectory) {
            if (dst.canonicalPath.startsWith(src.canonicalPath + File.separator) || dst.canonicalPath == src.canonicalPath)
                throw IllegalStateException("Нельзя копировать папку внутрь себя")
            dst.mkdirs()
            src.listFiles()?.forEach { copy(it, File(dst, it.name)) }
        } else {
            src.copyTo(dst, overwrite = false)
        }
    }

    fun move(src: File, dst: File) {
        if (!src.renameTo(dst)) {
            copy(src, dst)
            src.deleteRecursively()
        }
    }

    fun zip(files: List<File>, out: File) {
        ZipOutputStream(out.outputStream().buffered()).use { z ->
            files.forEach { addToZip(z, it, it.parentFile ?: it) }
        }
    }

    private fun addToZip(z: ZipOutputStream, f: File, base: File) {
        val name = f.relativeTo(base).path.replace('\\', '/')
        if (f.isDirectory) {
            z.putNextEntry(ZipEntry("$name/")); z.closeEntry()
            f.listFiles()?.forEach { addToZip(z, it, base) }
        } else {
            z.putNextEntry(ZipEntry(name))
            f.inputStream().use { it.copyTo(z) }
            z.closeEntry()
        }
    }

    fun unzip(zip: File, dest: File) {
        dest.mkdirs()
        val canon = dest.canonicalPath
        ZipInputStream(zip.inputStream().buffered()).use { zi ->
            while (true) {
                val e = zi.nextEntry ?: break
                val out = File(dest, e.name)
                if (!out.canonicalPath.startsWith(canon + File.separator)) throw SecurityException("Небезопасный путь в архиве")
                if (e.isDirectory) out.mkdirs() else {
                    out.parentFile?.mkdirs()
                    out.outputStream().use { zi.copyTo(it) }
                }
                zi.closeEntry()
            }
        }
    }

    /** Возвращает (размер, число файлов). */
    fun folderStats(f: File): Pair<Long, Int> {
        if (f.isFile) return f.length() to 1
        var size = 0L; var count = 0
        f.walkTopDown().forEach { if (it.isFile) { size += it.length(); count++ } }
        return size to count
    }
}
