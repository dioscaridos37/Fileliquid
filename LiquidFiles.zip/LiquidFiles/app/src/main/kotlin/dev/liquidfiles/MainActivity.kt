package dev.liquidfiles

import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.layout.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

class MainActivity : ComponentActivity() {
    private val vm: MainViewModel by viewModels()
    private var granted by mutableStateOf(false)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        granted = Environment.isExternalStorageManager()
        setContent {
            if (!vm.ready) return@setContent
            LiquidTheme(vm.settings) {
                if (granted) MainScreen(vm) else PermissionScreen { requestAllFiles() }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        val g = Environment.isExternalStorageManager()
        if (g && !granted) { granted = true; vm.refresh(); vm.loadStorage() }
        granted = g
    }

    private fun requestAllFiles() {
        try {
            startActivity(
                Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:$packageName"))
            )
        } catch (e: Exception) {
            startActivity(Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION))
        }
    }
}

@Composable
private fun PermissionScreen(onGrant: () -> Unit) {
    androidx.compose.foundation.layout.Box(Modifier.fillMaxSize()) {
        Wallpaper()
        Column(
            Modifier.align(Alignment.Center).padding(28.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            GlassSurface(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(14.dp)) {
                    T("Нужен доступ к файлам", size = 22.sp, weight = androidx.compose.ui.text.font.FontWeight.Bold)
                    T(
                        "Чтобы показывать и менять файлы во всей памяти, Android просит разрешить «Доступ ко всем файлам».",
                        size = 15.sp, color = inkSoft(), maxLines = 6,
                    )
                    GlassButton("Открыть настройки", onGrant, primary = true)
                }
            }
        }
    }
}
