package dev.liquidfiles

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.util.Locale

@Composable
fun SettingsScreen(vm: MainViewModel) {
    val s = vm.settings
    val top = WindowInsets.statusBars.asPaddingValues().calculateTopPadding()

    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = top + 16.dp, bottom = 150.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        item { T("Настройки", size = 34.sp, weight = FontWeight.Bold) }

        item {
            Section("Оформление") {
                Label("Тема")
                LiquidSwitcher(
                    items = listOf(TabSpec("Система"), TabSpec("Светлая"), TabSpec("Тёмная")),
                    selected = s.themeMode, onSelect = { i -> vm.update { it.copy(themeMode = i) } },
                    height = 52.dp, textSize = 14.sp,
                )
                Label("Акцентный цвет")
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    AccentPalette.forEachIndexed { i, c ->
                        AccentDot(Color(c), s.accent == i) { vm.update { it.copy(accent = i) } }
                    }
                }
                Label("Обои")
                LiquidSwitcher(
                    items = Wallpapers.map { TabSpec(it) },
                    selected = s.wallpaper, onSelect = { i -> vm.update { it.copy(wallpaper = i) } },
                    height = 52.dp, textSize = 13.sp,
                )
            }
        }

        item {
            Section("Жидкое стекло") {
                Label("Стиль")
                LiquidSwitcher(
                    items = GlassPresets.map { TabSpec(it) },
                    selected = s.glassStyle, onSelect = { i -> vm.update { it.withPreset(i) } },
                    height = 52.dp, textSize = 13.sp,
                )
                SliderRow("Размытие", s.blur, 0f..60f, { "${it.toInt()}" }) { v -> vm.update { it.copy(blur = v) } }
                SliderRow("Плотность стекла", s.glassAlpha, 0.05f..1f, pct) { v -> vm.update { it.copy(glassAlpha = v) } }
                SliderRow("Преломление линзы", s.refraction, 0f..1f, pct) { v -> vm.update { it.copy(refraction = v) } }
                SliderRow("Цветная аберрация", s.aberration, 0f..1f, pct) { v -> vm.update { it.copy(aberration = v) } }
                SliderRow("Скругление", s.corner, 8f..44f, { "${it.toInt()}" }) { v -> vm.update { it.copy(corner = v) } }
            }
        }

        item {
            Section("Анимации") {
                SliderRow("Упругость и «прыгучесть»", s.bounce, 0f..1f, pct) { v -> vm.update { it.copy(bounce = v) } }
                SwitchRow("Вибро-отклик", s.haptics) { v -> vm.update { it.copy(haptics = v) } }
                Label("Потяни линзу в панели внизу, чтобы почувствовать упругость.")
            }
        }

        item {
            Section("Файлы") {
                SwitchRow("Плиткой по умолчанию", s.gridMode) { v -> vm.update { it.copy(gridMode = v) } }
                SwitchRow("Показывать скрытые файлы", s.showHidden) { v -> vm.update { it.copy(showHidden = v) } }
                SwitchRow("Папки сверху", s.foldersFirst) { v -> vm.update { it.copy(foldersFirst = v) } }
            }
        }

        item {
            Section("О приложении") {
                T("Liquid Files 1.0.0", size = 15.sp)
                T("Android 17 · Jetpack Compose · AGSL", size = 13.sp, color = inkSoft())
            }
        }
    }
}

private val pct: (Float) -> String = { "${(it * 100).toInt()}%" }

@Composable
private fun Section(title: String, content: @Composable ColumnScope.() -> Unit) {
    GlassSurface(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            T(title, size = 18.sp, weight = FontWeight.SemiBold)
            content()
        }
    }
}

@Composable
private fun Label(text: String) = T(text, size = 13.sp, color = inkSoft(), maxLines = 3)

@Composable
private fun SwitchRow(title: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        T(title, size = 15.sp, modifier = Modifier.weight(1f))
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

@Composable
private fun SliderRow(title: String, value: Float, range: ClosedFloatingPointRange<Float>, fmt: (Float) -> String, onChange: (Float) -> Unit) {
    Column {
        Row(Modifier.fillMaxWidth()) {
            T(title, size = 15.sp, modifier = Modifier.weight(1f))
            T(fmt(value), size = 14.sp, color = inkSoft())
        }
        Slider(value = value, onValueChange = onChange, valueRange = range)
    }
}

@Composable
private fun AccentDot(color: Color, selected: Boolean, onClick: () -> Unit) {
    val sc by animateFloatAsState(if (selected) 1.18f else 1f, LocalMotion.current.spec(), label = "dot")
    Box(
        Modifier.size(32.dp).graphicsLayer { scaleX = sc; scaleY = sc }.bouncy(onClick = onClick)
            .clip(CircleShape).background(color)
            .then(if (selected) Modifier.border(2.dp, Color.White, CircleShape) else Modifier),
        contentAlignment = Alignment.Center,
    ) { if (selected) Icon(Icons.Rounded.Check, null, tint = Color.White, modifier = Modifier.size(16.dp)) }
}
